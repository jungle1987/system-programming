#pragma once
#pragma once
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <sstream> 
#include <vector> 
#include <chrono>
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>



void bufer_nusk(std::string read_vardas, std::string write_vardas);

using std::cout;
using std::cin;
using std::string;
using std::vector;
using std::endl;
using std::stringstream;
using namespace std::chrono;
using std::ofstream;