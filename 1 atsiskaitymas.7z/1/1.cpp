﻿

#include "library.h"
#include "buffer.h"



int main()
{
    cout << "Greitas variantas (per bufer'į):\n";
    bufer_nusk("studentai10000.txt", "studentai_copy.txt");
}
