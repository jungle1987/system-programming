﻿#include "buffer.h"


void bufer_nusk(string read_vardas, string write_vardas) {
    vector<string> splited;//vektorius stringam, pavadinimu splited
    string eil;//sukuriamas eil objektas duomenu nuskaitymui
    stringstream my_buffer;

    auto start = std::chrono::high_resolution_clock::now(); auto st = start;//skaiciuoja laika atliekamos operacijos
    std::ifstream open_f(read_vardas);//paimu duomenis is studentu failo
    my_buffer << open_f.rdbuf();//sukeliu duomenis i my_buffer objekta. rdbuf() metodas iraso duomenis i kompiuterio atmintine.
    open_f.close();//nuskaicius faila - uzdarau faila.
    std::chrono::duration<double> diff = std::chrono::high_resolution_clock::now() - start; // Skirtumas (s)
    cout << "Failo nuskaitymas į buferį užtruko: " << diff.count() << " s\n";

    start = std::chrono::high_resolution_clock::now();
    while (my_buffer) { //kol mano objektas nera tuscias
        if (!my_buffer.eof()) {
            std::getline(my_buffer, eil);//paimu viena eilute is my_buffer ir kiekviena eilute priskiriu i eil objekta
            splited.push_back(eil);//pushinu duomenis i vektoriu splited is eil objekto
        }
        else break;
    }
    diff = std::chrono::high_resolution_clock::now() - start; // Skirtumas (s)
    std::cout << "Buferio padalijimas į eilučių vektorių užtruko: " << diff.count() << " s\n";

    start = std::chrono::high_resolution_clock::now();
    std::string outputas = "";
    for (std::string& a : splited) (a.compare(*splited.rbegin()) != 0) ? outputas += a + "\n" : outputas += a;
    splited.clear();
    diff = std::chrono::high_resolution_clock::now() - start; // Skirtumas (s)
    cout << "Eilučių vektoriiaus konvertavimas į vieną eilutę užtruko: " << diff.count() << " s\n";

    start = std::chrono::high_resolution_clock::now();
    ofstream out_f(write_vardas);
    out_f << outputas;
    out_f.close();
    diff = std::chrono::high_resolution_clock::now() - start; // Skirtumas (s)
    cout << "Failo įrašymas per vieną eilutę užtruko: " << diff.count() << " s\n";

    diff = std::chrono::high_resolution_clock::now() - st; // Skirtumas (s)
    std::cout << "Visas sugaištas laikas: " << diff.count() << " s\n\n";

}